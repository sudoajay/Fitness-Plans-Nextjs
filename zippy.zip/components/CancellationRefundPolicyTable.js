export function CancellationRefundPolicyTable() {
  return (
    <div class="mx-auto container flex items-center" id="nav">
      <div class="w-full pt-0 p-8">
        <div class="mx-auto md:p-2 md:w-1/2">
          <div class="bg-white shadow-md rounded px-8 pt-4 mb-6">
            <p class="font-normal text-base  font-primary pb-2">Last updated: June 02, 2023</p>
            <p class="font-normal text-base  font-primary pb-2">No cancellations & Refunds are entertained</p>
          
          </div>
        </div>
      </div>
    </div>
  );
}
